import 'package:flutter/cupertino.dart';

const mainTextStyle =
    TextStyle(fontFamily: "cairo", fontWeight: FontWeight.bold);
const scecondaryTextStyle =
    TextStyle(fontFamily: "cairo", fontSize: 14, fontWeight: FontWeight.w400);
