import 'package:flutter/material.dart';

const Color mainColor = Color(0xFFE92B6B);

const Color scecondaryColor = Color.fromARGB(255, 233, 43, 107);
