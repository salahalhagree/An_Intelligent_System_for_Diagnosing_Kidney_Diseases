package com.Education_Soft.dengue_fever_diagnosis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
